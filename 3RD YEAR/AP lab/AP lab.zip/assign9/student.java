import java.awt.*;
import javax.swing.*;
public class student extends JApplet
{
public void init()
{
System.out.println("Init function");
}
public void start()
{System.out.println("Start function");
}
public void stop()
{System.out.println("Stop function");
}
public void destroy()
{System.out.println("Destroy function");
}
//public void paint(Graphics g)
//{

//}
}