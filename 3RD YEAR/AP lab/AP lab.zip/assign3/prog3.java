class prog3
{
public static void main(String arg[])
{
String name=arg[0];
System.out.println("Name is:"+name);
}
}