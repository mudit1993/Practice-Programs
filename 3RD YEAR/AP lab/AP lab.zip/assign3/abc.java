import java.io.*;
class abc
{
public static void main(String arg[])
{
System.out.println("Hello JAVA!");
}
}