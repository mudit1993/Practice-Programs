package mypkg;
public class Pack
{
public void disp()
{
System.out.println("Function of Class mypkg.Pack");
}
}