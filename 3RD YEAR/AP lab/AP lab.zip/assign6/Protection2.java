package P2;
public class Protection2 extends P1.Protection
{
public Protection2()
{
System.out.println("Constructor of Protection2");
System.out.println("Public var:"+j);
//System.out.println("Default var:"+i);
System.out.println("Protected var:"+l);
//System.out.println("private var:"+k);
}
} 