import mypkg.*;
class Pack1
{
public static void main(String arg[])
{
Pack obj=new Pack();
obj.disp();
}
}