package P1;
public class Demo1
{
public static void main(String arg[])
{
Protection p=new Protection();
Derived d=new Derived();
SamePackage ob1=new SamePackage();
}
}