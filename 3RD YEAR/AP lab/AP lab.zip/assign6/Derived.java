package P1;
public class Derived extends Protection
{
public Derived()
{
System.out.println("Constructor of Derived");
System.out.println("Public var:"+j);
//System.out.println("Default var:"+i);
System.out.println("Protected var:"+l);
//System.out.println("private var:"+k);
}
}