package P2;
public class Demo2
{
public static void main(String arg[])
{
OtherPackage ob1=new OtherPackage();
Protection2 p=new Protection2();
}
}